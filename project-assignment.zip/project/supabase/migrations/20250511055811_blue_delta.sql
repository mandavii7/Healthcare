/*
  # Healthcare Management System Database Schema

  1. New Tables
    - `patients`
      - Core patient information
      - Personal and contact details
      - Insurance and admission information
    - `vital_signs` 
      - Patient vital sign measurements
      - Linked to patients through patient_id
    - `appointments`
      - Follow-up and scheduled appointments
      - Tracks status and details of patient visits
    - `patient_conditions`
      - Medical conditions and diagnoses
      - Historical record of patient health issues
    - `medications`
      - Prescribed medications tracking
      - Dosage, frequency and active status
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to read/write
*/

-- Create patients table
CREATE TABLE IF NOT EXISTS patients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  firstName text NOT NULL,
  lastName text NOT NULL,
  dateOfBirth text NOT NULL,
  gender text NOT NULL,
  contactNumber text NOT NULL,
  email text NOT NULL,
  address text NOT NULL,
  insuranceProvider text,
  insuranceNumber text,
  emergencyContact text,
  emergencyPhone text,
  admissionDate text,
  dischargeDate text,
  assignedDoctor text,
  bloodType text,
  created_at timestamptz DEFAULT now()
);

-- Create vital signs table
CREATE TABLE IF NOT EXISTS vital_signs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patientId uuid REFERENCES patients(id) ON DELETE CASCADE NOT NULL,
  date text NOT NULL,
  temperature float NOT NULL,
  heartRate integer NOT NULL,
  bloodPressureSystolic integer NOT NULL,
  bloodPressureDiastolic integer NOT NULL,
  respiratoryRate integer NOT NULL,
  oxygenSaturation integer NOT NULL,
  notes text,
  created_at timestamptz DEFAULT now()
);

-- Create appointments table
CREATE TABLE IF NOT EXISTS appointments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patientId uuid REFERENCES patients(id) ON DELETE CASCADE NOT NULL,
  date text NOT NULL,
  time text NOT NULL,
  doctorName text NOT NULL,
  purpose text NOT NULL,
  notes text,
  completed boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create patient conditions table
CREATE TABLE IF NOT EXISTS patient_conditions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patientId uuid REFERENCES patients(id) ON DELETE CASCADE NOT NULL,
  condition text NOT NULL,
  diagnosisDate text,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Create medications table
CREATE TABLE IF NOT EXISTS medications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patientId uuid REFERENCES patients(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  dosage text NOT NULL,
  frequency text NOT NULL,
  startDate text NOT NULL,
  endDate text,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Create health check table for application status monitoring
CREATE TABLE IF NOT EXISTS health_check (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  status text DEFAULT 'ok',
  lastChecked timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE vital_signs ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE patient_conditions ENABLE ROW LEVEL SECURITY;
ALTER TABLE medications ENABLE ROW LEVEL SECURITY;
ALTER TABLE health_check ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Allow authenticated users to read patients" 
  ON patients FOR SELECT TO authenticated USING (true);

CREATE POLICY "Allow authenticated users to insert patients" 
  ON patients FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Allow authenticated users to update patients" 
  ON patients FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Allow authenticated users to read vital signs" 
  ON vital_signs FOR SELECT TO authenticated USING (true);

CREATE POLICY "Allow authenticated users to insert vital signs" 
  ON vital_signs FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Allow authenticated users to read appointments" 
  ON appointments FOR SELECT TO authenticated USING (true);

CREATE POLICY "Allow authenticated users to insert appointments" 
  ON appointments FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Allow authenticated users to update appointments" 
  ON appointments FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Allow authenticated users to read patient conditions" 
  ON patient_conditions FOR SELECT TO authenticated USING (true);

CREATE POLICY "Allow authenticated users to read medications" 
  ON medications FOR SELECT TO authenticated USING (true);

CREATE POLICY "Allow authenticated users to read health check" 
  ON health_check FOR SELECT TO authenticated USING (true);

-- Insert initial health check data
INSERT INTO health_check (status) VALUES ('ok');