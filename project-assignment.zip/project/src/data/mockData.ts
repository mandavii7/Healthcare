import { AnalyticsData, FollowupAppointment, Patient, VitalSign } from '../types';
import { v4 as uuidv4 } from 'uuid';

// Generate a random date between start and end
const randomDate = (start: Date, end: Date) => {
  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime())).toISOString().split('T')[0];
};

// Generate random number between min and max
const randomNumber = (min: number, max: number) => {
  return Math.floor(Math.random() * (max - min + 1) + min);
};

// Generate vital signs for a patient
const generateVitalSigns = (patientId: string, count: number): VitalSign[] => {
  const vitalSigns: VitalSign[] = [];
  const today = new Date();
  
  for (let i = 0; i < count; i++) {
    const date = new Date(today);
    date.setDate(today.getDate() - i * 2);
    
    vitalSigns.push({
      id: uuidv4(),
      patientId,
      date: date.toISOString().split('T')[0],
      temperature: 36 + Math.random() * 2,
      heartRate: randomNumber(60, 100),
      bloodPressureSystolic: randomNumber(110, 140),
      bloodPressureDiastolic: randomNumber(70, 90),
      respiratoryRate: randomNumber(12, 20),
      oxygenSaturation: randomNumber(95, 100),
      notes: i % 3 === 0 ? 'Patient reported feeling better' : undefined
    });
  }
  
  return vitalSigns;
};

// Generate followup appointments for a patient
const generateFollowups = (patientId: string, count: number): FollowupAppointment[] => {
  const followups: FollowupAppointment[] = [];
  const today = new Date();
  const doctors = ['Dr. Smith', 'Dr. Johnson', 'Dr. Williams', 'Dr. Brown', 'Dr. Davis'];
  const purposes = ['Regular checkup', 'Post-surgery follow up', 'Medication review', 'Lab results discussion', 'Treatment evaluation'];
  
  for (let i = 0; i < count; i++) {
    const date = new Date(today);
    date.setDate(today.getDate() + randomNumber(-30, 30));
    
    followups.push({
      id: uuidv4(),
      patientId,
      date: date.toISOString().split('T')[0],
      time: `${randomNumber(9, 16)}:${randomNumber(0, 5)}0`,
      doctorName: doctors[randomNumber(0, doctors.length - 1)],
      purpose: purposes[randomNumber(0, purposes.length - 1)],
      notes: i % 3 === 0 ? 'Patient requested morning appointment' : undefined,
      completed: date < today
    });
  }
  
  return followups;
};

// Generate mock patients
export const generateMockPatients = (count: number): Patient[] => {
  const firstNames = ['John', 'Jane', 'Michael', 'Emily', 'David', 'Sarah', 'Robert', 'Linda', 'William', 'Elizabeth'];
  const lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Miller', 'Davis', 'Garcia', 'Rodriguez', 'Wilson'];
  const bloodTypes = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  const allergies = ['Penicillin', 'Peanuts', 'Latex', 'Shellfish', 'Dairy', 'Pollen', 'Dust', 'None'];
  const medicalHistory = ['Hypertension', 'Diabetes', 'Asthma', 'Heart Disease', 'Cancer', 'Stroke', 'Arthritis', 'None'];
  const medications = ['Lisinopril', 'Metformin', 'Atorvastatin', 'Amlodipine', 'Albuterol', 'Metoprolol', 'Omeprazole', 'None'];
  const doctors = ['Dr. Smith', 'Dr. Johnson', 'Dr. Williams', 'Dr. Brown', 'Dr. Davis'];
  
  const patients: Patient[] = [];
  
  for (let i = 0; i < count; i++) {
    const id = uuidv4();
    const gender = Math.random() > 0.5 ? 'Male' : 'Female';
    const firstName = firstNames[randomNumber(0, firstNames.length - 1)];
    const lastName = lastNames[randomNumber(0, lastNames.length - 1)];
    const admissionDate = randomDate(new Date(2023, 0, 1), new Date());
    
    // Calculate discharge date (null for some patients to indicate they're still admitted)
    let dischargeDate = undefined;
    if (Math.random() > 0.3) {
      const admissionDt = new Date(admissionDate);
      const dischargeDt = new Date(admissionDt);
      dischargeDt.setDate(admissionDt.getDate() + randomNumber(1, 14));
      dischargeDate = dischargeDt.toISOString().split('T')[0];
    }
    
    // Generate a random date of birth
    const dobYear = randomNumber(1940, 2005);
    const dobMonth = randomNumber(1, 12);
    const dobDay = randomNumber(1, 28);
    const dateOfBirth = `${dobYear}-${dobMonth.toString().padStart(2, '0')}-${dobDay.toString().padStart(2, '0')}`;
    
    // Create random allergies, medical history, and medications
    const patientAllergies = [];
    const patientHistory = [];
    const patientMedications = [];
    
    for (let j = 0; j < randomNumber(0, 3); j++) {
      patientAllergies.push(allergies[randomNumber(0, allergies.length - 1)]);
      patientHistory.push(medicalHistory[randomNumber(0, medicalHistory.length - 1)]);
      patientMedications.push(medications[randomNumber(0, medications.length - 1)]);
    }
    
    const patient: Patient = {
      id,
      firstName,
      lastName,
      dateOfBirth,
      gender: gender as 'Male' | 'Female' | 'Other',
      contactNumber: `(${randomNumber(100, 999)}) ${randomNumber(100, 999)}-${randomNumber(1000, 9999)}`,
      email: `${firstName.toLowerCase()}.${lastName.toLowerCase()}@example.com`,
      address: `${randomNumber(100, 9999)} Main St, Anytown, ST ${randomNumber(10000, 99999)}`,
      insuranceProvider: Math.random() > 0.1 ? ['BlueCross', 'Aetna', 'UnitedHealth', 'Cigna', 'Humana'][randomNumber(0, 4)] : undefined,
      insuranceNumber: Math.random() > 0.1 ? `INS-${randomNumber(100000, 999999)}` : undefined,
      emergencyContact: `${firstNames[randomNumber(0, firstNames.length - 1)]} ${lastNames[randomNumber(0, lastNames.length - 1)]}`,
      emergencyPhone: `(${randomNumber(100, 999)}) ${randomNumber(100, 999)}-${randomNumber(1000, 9999)}`,
      admissionDate,
      dischargeDate,
      assignedDoctor: doctors[randomNumber(0, doctors.length - 1)],
      bloodType: bloodTypes[randomNumber(0, bloodTypes.length - 1)],
      allergies: patientAllergies.length > 0 ? [...new Set(patientAllergies)] : undefined,
      medicalHistory: patientHistory.length > 0 ? [...new Set(patientHistory)] : undefined,
      currentMedications: patientMedications.length > 0 ? [...new Set(patientMedications)] : undefined,
      vitalSigns: generateVitalSigns(id, randomNumber(3, 7)),
      followupAppointments: generateFollowups(id, randomNumber(1, 4))
    };
    
    patients.push(patient);
  }
  
  return patients;
};

// Generate mock analytics data
export const generateMockAnalytics = (patients: Patient[]): AnalyticsData => {
  // Count patients by gender
  const genderCounts = patients.reduce((acc, patient) => {
    acc[patient.gender] = (acc[patient.gender] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  
  const patientsByGender = Object.entries(genderCounts).map(([label, value]) => ({ label, value }));
  
  // Group patients by age
  const currentYear = new Date().getFullYear();
  const ageGroups: Record<string, number> = {
    'Under 18': 0,
    '18-30': 0,
    '31-45': 0,
    '46-60': 0,
    '61-75': 0,
    'Over 75': 0
  };
  
  patients.forEach(patient => {
    const birthYear = parseInt(patient.dateOfBirth.split('-')[0]);
    const age = currentYear - birthYear;
    
    if (age < 18) ageGroups['Under 18']++;
    else if (age <= 30) ageGroups['18-30']++;
    else if (age <= 45) ageGroups['31-45']++;
    else if (age <= 60) ageGroups['46-60']++;
    else if (age <= 75) ageGroups['61-75']++;
    else ageGroups['Over 75']++;
  });
  
  const patientsByAge = Object.entries(ageGroups).map(([label, value]) => ({ label, value }));
  
  // Count admissions by month
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const admissionCounts = Array(12).fill(0);
  
  patients.forEach(patient => {
    if (patient.admissionDate) {
      const month = parseInt(patient.admissionDate.split('-')[1]) - 1;
      admissionCounts[month]++;
    }
  });
  
  const admissionsByMonth = months.map((month, index) => ({
    month,
    count: admissionCounts[index]
  }));
  
  // Calculate average stay duration
  let totalStayDays = 0;
  let stayCount = 0;
  
  patients.forEach(patient => {
    if (patient.admissionDate && patient.dischargeDate) {
      const admissionDate = new Date(patient.admissionDate);
      const dischargeDate = new Date(patient.dischargeDate);
      const stayDays = Math.round((dischargeDate.getTime() - admissionDate.getTime()) / (1000 * 60 * 60 * 24));
      
      totalStayDays += stayDays;
      stayCount++;
    }
  });
  
  const averageStayDuration = stayCount > 0 ? Math.round(totalStayDays / stayCount * 10) / 10 : 0;
  
  // Generate vital trends data
  const vitalDates = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - i);
    return date.toISOString().split('T')[0];
  }).reverse();
  
  const heartRateData = vitalDates.map(() => randomNumber(70, 85));
  const bloodPressureData = vitalDates.map(() => randomNumber(120, 135));
  
  const vitalTrends = {
    labels: vitalDates,
    datasets: [
      {
        name: 'Avg Heart Rate',
        data: heartRateData
      },
      {
        name: 'Avg Systolic BP',
        data: bloodPressureData
      }
    ]
  };
  
  // Generate risk assessment data
  const riskAssessment = {
    highRisk: randomNumber(3, 8),
    mediumRisk: randomNumber(10, 20),
    lowRisk: randomNumber(30, 50)
  };
  
  return {
    patientsByGender,
    patientsByAge,
    admissionsByMonth,
    averageStayDuration,
    vitalTrends,
    riskAssessment
  };
};

// Initialize with 30 mock patients
export const mockPatients = generateMockPatients(30);
export const mockAnalytics = generateMockAnalytics(mockPatients);