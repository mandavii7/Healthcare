import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { mockAnalytics } from '../data/mockData';
import { AnalyticsData } from '../types';
import { usePatients } from './PatientContext';
import { generateMockAnalytics } from '../data/mockData';

interface AnalyticsContextType {
  analytics: AnalyticsData;
  loading: boolean;
  error: string | null;
  refreshAnalytics: () => void;
  getRiskAssessment: () => { highRisk: number; mediumRisk: number; lowRisk: number };
}

const AnalyticsContext = createContext<AnalyticsContextType | undefined>(undefined);

export const AnalyticsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { patients } = usePatients();
  const [analytics, setAnalytics] = useState<AnalyticsData>(mockAnalytics);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    refreshAnalytics();
  }, [patients]);

  const refreshAnalytics = () => {
    setLoading(true);
    try {
      // Generate analytics from current patient data
      const newAnalytics = generateMockAnalytics(patients);
      setAnalytics(newAnalytics);
    } catch (err) {
      setError('Failed to refresh analytics');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getRiskAssessment = () => {
    return analytics.riskAssessment;
  };

  return (
    <AnalyticsContext.Provider 
      value={{ 
        analytics, 
        loading, 
        error, 
        refreshAnalytics,
        getRiskAssessment
      }}
    >
      {children}
    </AnalyticsContext.Provider>
  );
};

export const useAnalytics = () => {
  const context = useContext(AnalyticsContext);
  if (context === undefined) {
    throw new Error('useAnalytics must be used within an AnalyticsProvider');
  }
  return context;
};