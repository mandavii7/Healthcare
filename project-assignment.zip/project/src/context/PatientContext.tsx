import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { mockPatients } from '../data/mockData';
import { Patient } from '../types';
import { supabase } from '../lib/supabase';
import { v4 as uuidv4 } from 'uuid';

interface PatientContextType {
  patients: Patient[];
  loading: boolean;
  error: string | null;
  addPatient: (patient: Omit<Patient, 'id'>) => Promise<void>;
  updatePatient: (id: string, data: Partial<Patient>) => Promise<void>;
  deletePatient: (id: string) => Promise<void>;
  getPatientById: (id: string) => Patient | undefined;
  searchPatients: (query: string) => Patient[];
}

const PatientContext = createContext<PatientContextType | undefined>(undefined);

export const PatientProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [patients, setPatients] = useState<Patient[]>(mockPatients);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [supabaseAvailable, setSupabaseAvailable] = useState(false);

  // Check if Supabase is available
  useEffect(() => {
    const checkSupabase = async () => {
      try {
        if (!import.meta.env.VITE_SUPABASE_URL) {
          console.log('Using mock data: Supabase not configured');
          return;
        }

        const { data, error } = await supabase.from('health_check').select('*').limit(1);
        
        if (error) {
          console.log('Using mock data: Supabase not available', error);
          return;
        }

        setSupabaseAvailable(true);
        console.log('Supabase is available');
      } catch (error) {
        console.log('Using mock data: Supabase connection error');
      }
    };

    checkSupabase();
  }, []);

  // Load patients from Supabase if available
  useEffect(() => {
    if (!supabaseAvailable) return;

    const fetchPatients = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('patients')
          .select('*');
          
        if (error) throw error;
        
        if (data) {
          setPatients(data as Patient[]);
        }
      } catch (err) {
        setError('Failed to fetch patients');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchPatients();
  }, [supabaseAvailable]);

  // Add a new patient
  const addPatient = async (patient: Omit<Patient, 'id'>) => {
    const newPatient = { ...patient, id: uuidv4() };
    
    if (supabaseAvailable) {
      try {
        const { error } = await supabase
          .from('patients')
          .insert([newPatient]);
          
        if (error) throw error;
      } catch (err) {
        setError('Failed to add patient');
        console.error(err);
        return;
      }
    }
    
    setPatients(prev => [...prev, newPatient as Patient]);
  };

  // Update an existing patient
  const updatePatient = async (id: string, data: Partial<Patient>) => {
    if (supabaseAvailable) {
      try {
        const { error } = await supabase
          .from('patients')
          .update(data)
          .eq('id', id);
          
        if (error) throw error;
      } catch (err) {
        setError('Failed to update patient');
        console.error(err);
        return;
      }
    }
    
    setPatients(prev => 
      prev.map(patient => 
        patient.id === id ? { ...patient, ...data } : patient
      )
    );
  };

  // Delete a patient
  const deletePatient = async (id: string) => {
    if (supabaseAvailable) {
      try {
        const { error } = await supabase
          .from('patients')
          .delete()
          .eq('id', id);
          
        if (error) throw error;
      } catch (err) {
        setError('Failed to delete patient');
        console.error(err);
        return;
      }
    }
    
    setPatients(prev => prev.filter(patient => patient.id !== id));
  };

  // Get a patient by ID
  const getPatientById = (id: string) => {
    return patients.find(patient => patient.id === id);
  };

  // Search patients by name, email, or condition
  const searchPatients = (query: string) => {
    if (!query) return patients;
    
    const lowerQuery = query.toLowerCase();
    return patients.filter(patient => 
      `${patient.firstName} ${patient.lastName}`.toLowerCase().includes(lowerQuery) ||
      patient.email.toLowerCase().includes(lowerQuery) ||
      patient.medicalHistory?.some(condition => 
        condition.toLowerCase().includes(lowerQuery)
      )
    );
  };

  return (
    <PatientContext.Provider 
      value={{ 
        patients, 
        loading, 
        error, 
        addPatient, 
        updatePatient, 
        deletePatient, 
        getPatientById,
        searchPatients
      }}
    >
      {children}
    </PatientContext.Provider>
  );
};

export const usePatients = () => {
  const context = useContext(PatientContext);
  if (context === undefined) {
    throw new Error('usePatients must be used within a PatientProvider');
  }
  return context;
};