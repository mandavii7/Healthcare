export interface Database {
  public: {
    Tables: {
      patients: {
        Row: {
          id: string;
          firstName: string;
          lastName: string;
          dateOfBirth: string;
          gender: 'Male' | 'Female' | 'Other';
          contactNumber: string;
          email: string;
          address: string;
          insuranceProvider?: string;
          insuranceNumber?: string;
          emergencyContact?: string;
          emergencyPhone?: string;
          admissionDate?: string;
          dischargeDate?: string;
          assignedDoctor?: string;
          bloodType?: string;
          created_at?: string;
        };
        Insert: {
          id: string;
          firstName: string;
          lastName: string;
          dateOfBirth: string;
          gender: 'Male' | 'Female' | 'Other';
          contactNumber: string;
          email: string;
          address: string;
          insuranceProvider?: string;
          insuranceNumber?: string;
          emergencyContact?: string;
          emergencyPhone?: string;
          admissionDate?: string;
          dischargeDate?: string;
          assignedDoctor?: string;
          bloodType?: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          firstName?: string;
          lastName?: string;
          dateOfBirth?: string;
          gender?: 'Male' | 'Female' | 'Other';
          contactNumber?: string;
          email?: string;
          address?: string;
          insuranceProvider?: string;
          insuranceNumber?: string;
          emergencyContact?: string;
          emergencyPhone?: string;
          admissionDate?: string;
          dischargeDate?: string;
          assignedDoctor?: string;
          bloodType?: string;
          created_at?: string;
        };
      };
      vital_signs: {
        Row: {
          id: string;
          patientId: string;
          date: string;
          temperature: number;
          heartRate: number;
          bloodPressureSystolic: number;
          bloodPressureDiastolic: number;
          respiratoryRate: number;
          oxygenSaturation: number;
          notes?: string;
          created_at?: string;
        };
        Insert: {
          id: string;
          patientId: string;
          date: string;
          temperature: number;
          heartRate: number;
          bloodPressureSystolic: number;
          bloodPressureDiastolic: number;
          respiratoryRate: number;
          oxygenSaturation: number;
          notes?: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          patientId?: string;
          date?: string;
          temperature?: number;
          heartRate?: number;
          bloodPressureSystolic?: number;
          bloodPressureDiastolic?: number;
          respiratoryRate?: number;
          oxygenSaturation?: number;
          notes?: string;
          created_at?: string;
        };
      };
      appointments: {
        Row: {
          id: string;
          patientId: string;
          date: string;
          time: string;
          doctorName: string;
          purpose: string;
          notes?: string;
          completed: boolean;
          created_at?: string;
        };
        Insert: {
          id: string;
          patientId: string;
          date: string;
          time: string;
          doctorName: string;
          purpose: string;
          notes?: string;
          completed: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          patientId?: string;
          date?: string;
          time?: string;
          doctorName?: string;
          purpose?: string;
          notes?: string;
          completed?: boolean;
          created_at?: string;
        };
      };
      patient_conditions: {
        Row: {
          id: string;
          patientId: string;
          condition: string;
          diagnosisDate?: string;
          active: boolean;
          created_at?: string;
        };
        Insert: {
          id: string;
          patientId: string;
          condition: string;
          diagnosisDate?: string;
          active: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          patientId?: string;
          condition?: string;
          diagnosisDate?: string;
          active?: boolean;
          created_at?: string;
        };
      };
      medications: {
        Row: {
          id: string;
          patientId: string;
          name: string;
          dosage: string;
          frequency: string;
          startDate: string;
          endDate?: string;
          active: boolean;
          created_at?: string;
        };
        Insert: {
          id: string;
          patientId: string;
          name: string;
          dosage: string;
          frequency: string;
          startDate: string;
          endDate?: string;
          active: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          patientId?: string;
          name?: string;
          dosage?: string;
          frequency?: string;
          startDate?: string;
          endDate?: string;
          active?: boolean;
          created_at?: string;
        };
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      [_ in never]: never;
    };
    Enums: {
      [_ in never]: never;
    };
  };
}