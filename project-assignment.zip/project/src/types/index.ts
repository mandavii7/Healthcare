export interface Patient {
  id: string;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  gender: 'Male' | 'Female' | 'Other';
  contactNumber: string;
  email: string;
  address: string;
  insuranceProvider?: string;
  insuranceNumber?: string;
  emergencyContact?: string;
  emergencyPhone?: string;
  admissionDate?: string;
  dischargeDate?: string;
  assignedDoctor?: string;
  bloodType?: string;
  allergies?: string[];
  medicalHistory?: string[];
  currentMedications?: string[];
  vitalSigns?: VitalSign[];
  followupAppointments?: FollowupAppointment[];
}

export interface VitalSign {
  id: string;
  patientId: string;
  date: string;
  temperature: number;
  heartRate: number;
  bloodPressureSystolic: number;
  bloodPressureDiastolic: number;
  respiratoryRate: number;
  oxygenSaturation: number;
  notes?: string;
}

export interface FollowupAppointment {
  id: string;
  patientId: string;
  date: string;
  time: string;
  doctorName: string;
  purpose: string;
  notes?: string;
  completed: boolean;
}

export interface AnalyticsData {
  patientsByGender: { label: string; value: number }[];
  patientsByAge: { label: string; value: number }[];
  admissionsByMonth: { month: string; count: number }[];
  averageStayDuration: number;
  vitalTrends: {
    labels: string[];
    datasets: {
      name: string;
      data: number[];
    }[];
  };
  riskAssessment: {
    highRisk: number;
    mediumRisk: number;
    lowRisk: number;
  };
}

export type UserRole = 'doctor' | 'nurse' | 'admin' | 'receptionist';

export interface User {
  id: string;
  name: string;
  role: UserRole;
  department?: string;
}