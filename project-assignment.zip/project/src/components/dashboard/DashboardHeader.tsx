import React from 'react';
import { Calendar, RefreshCw, Download } from 'lucide-react';

const DashboardHeader: React.FC = () => {
  return (
    <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-800">Dashboard</h1>
        <p className="text-gray-500 mt-1">Welcome back, Dr. Roberts</p>
      </div>
      
      <div className="flex items-center space-x-2 mt-4 md:mt-0">
        <div className="flex items-center bg-white rounded-lg border border-gray-200 px-3 py-2 text-sm">
          <Calendar size={16} className="text-gray-500 mr-2" />
          <span>Jun 10 - Jun 17, 2025</span>
        </div>
        
        <button className="p-2 text-gray-500 hover:text-blue-600 bg-white rounded-lg border border-gray-200">
          <RefreshCw size={16} />
        </button>
        
        <button className="p-2 text-gray-500 hover:text-blue-600 bg-white rounded-lg border border-gray-200">
          <Download size={16} />
        </button>
      </div>
    </div>
  );
};

export default DashboardHeader;