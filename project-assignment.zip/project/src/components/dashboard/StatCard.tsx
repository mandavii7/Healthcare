import React from 'react';
import { ArrowUp, ArrowDown } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  change?: {
    value: number;
    type: 'increase' | 'decrease';
  };
  bgColor?: string;
}

const StatCard: React.FC<StatCardProps> = ({ 
  title, 
  value, 
  icon, 
  change, 
  bgColor = 'bg-blue-500'
}) => {
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
      <div className="p-5">
        <div className="flex items-center">
          <div className={`${bgColor} rounded-lg p-3 text-white`}>
            {icon}
          </div>
          <div className="ml-4">
            <h3 className="text-gray-500 text-sm font-medium">{title}</h3>
            <p className="text-2xl font-bold text-gray-800 mt-1">{value}</p>
          </div>
        </div>
        
        {change && (
          <div className="mt-4 flex items-center">
            <span 
              className={`flex items-center text-sm ${
                change.type === 'increase' ? 'text-green-600' : 'text-red-600'
              }`}
            >
              {change.type === 'increase' ? (
                <ArrowUp size={14} className="mr-1" />
              ) : (
                <ArrowDown size={14} className="mr-1" />
              )}
              {Math.abs(change.value)}%
            </span>
            <span className="text-gray-500 text-sm ml-2">vs last week</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default StatCard;