import React from 'react';
import { Clock, Heart } from 'lucide-react';

interface PatientListItemProps {
  name: string;
  gender: string;
  age: number;
  condition?: string;
  admissionDate: string;
  isHighRisk?: boolean;
  bloodPressure?: string;
  heartRate?: number;
}

const PatientListItem: React.FC<PatientListItemProps> = ({
  name,
  gender,
  age,
  condition,
  admissionDate,
  isHighRisk = false,
  bloodPressure,
  heartRate
}) => {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between p-4 border-b border-gray-100 hover:bg-gray-50 transition-colors">
      <div className="flex items-center">
        <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center font-semibold">
          {name.charAt(0)}
        </div>
        <div className="ml-3">
          <div className="flex items-center">
            <p className="font-medium text-gray-800">{name}</p>
            {isHighRisk && (
              <span className="ml-2 bg-red-100 text-red-800 text-xs px-2 py-0.5 rounded-full">
                High Risk
              </span>
            )}
          </div>
          <div className="flex items-center mt-1 text-sm text-gray-500">
            <span>{gender}</span>
            <span className="mx-2">•</span>
            <span>{age} years</span>
            {condition && (
              <>
                <span className="mx-2">•</span>
                <span>{condition}</span>
              </>
            )}
          </div>
        </div>
      </div>
      
      <div className="flex items-center mt-3 sm:mt-0">
        <div className="flex items-center text-sm">
          <Clock size={14} className="text-gray-400 mr-1" />
          <span className="text-gray-500">{admissionDate}</span>
        </div>
        
        {bloodPressure && heartRate && (
          <div className="ml-4 flex items-center text-sm">
            <Heart size={14} className="text-red-500 mr-1" />
            <span className="text-gray-500">{bloodPressure}, {heartRate} bpm</span>
          </div>
        )}
        
        <button className="ml-4 px-3 py-1 bg-blue-50 text-blue-600 rounded-md text-sm hover:bg-blue-100 transition-colors">
          View
        </button>
      </div>
    </div>
  );
};

export default PatientListItem;