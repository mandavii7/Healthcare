import React from 'react';
import { Clock, MapPin } from 'lucide-react';

interface AppointmentCardProps {
  time: string;
  patientName: string;
  purposeShort: string;
  location: string;
  status: 'upcoming' | 'completed' | 'cancelled';
}

const AppointmentCard: React.FC<AppointmentCardProps> = ({
  time,
  patientName,
  purposeShort,
  location,
  status
}) => {
  const getStatusColors = () => {
    switch (status) {
      case 'upcoming':
        return 'bg-blue-100 text-blue-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  const statusLabel = status.charAt(0).toUpperCase() + status.slice(1);
  
  return (
    <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-lg font-semibold text-gray-800">{patientName}</p>
          <p className="text-gray-500 mt-1">{purposeShort}</p>
          
          <div className="flex items-center mt-3 text-sm text-gray-500">
            <Clock size={14} className="mr-1" />
            <span>{time}</span>
          </div>
          
          <div className="flex items-center mt-1 text-sm text-gray-500">
            <MapPin size={14} className="mr-1" />
            <span>{location}</span>
          </div>
        </div>
        
        <span className={`${getStatusColors()} px-3 py-1 rounded-full text-xs font-medium`}>
          {statusLabel}
        </span>
      </div>
    </div>
  );
};

export default AppointmentCard;