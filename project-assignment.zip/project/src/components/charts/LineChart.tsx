import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

interface LineChartProps {
  data: {
    labels: string[];
    datasets: {
      name: string;
      data: number[];
      color?: string;
    }[];
  };
  width?: number;
  height?: number;
  title?: string;
}

const LineChart: React.FC<LineChartProps> = ({ 
  data, 
  width = 500, 
  height = 300,
  title
}) => {
  const svgRef = useRef<SVGSVGElement>(null);
  
  useEffect(() => {
    if (!data || !svgRef.current) return;
    
    // Clear previous chart
    d3.select(svgRef.current).selectAll('*').remove();
    
    const svg = d3.select(svgRef.current);
    
    // Set margins
    const margin = { top: 20, right: 50, bottom: 40, left: 50 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;
    
    // Create scales
    const xScale = d3.scalePoint()
      .domain(data.labels)
      .range([0, innerWidth]);
    
    const allValues = data.datasets.flatMap(dataset => dataset.data);
    const yMax = d3.max(allValues) || 0;
    
    const yScale = d3.scaleLinear()
      .domain([0, yMax * 1.1]) // Add some padding at the top
      .nice()
      .range([innerHeight, 0]);
    
    // Create chart group
    const g = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);
    
    // Define line generator
    const line = d3.line<number>()
      .x((_, i) => xScale(data.labels[i]) || 0)
      .y(d => yScale(d))
      .curve(d3.curveMonotoneX);
    
    // Default colors if not provided
    const colors = ['#3B82F6', '#10B981', '#F97316', '#8B5CF6'];
    
    // Draw lines for each dataset
    data.datasets.forEach((dataset, datasetIndex) => {
      const color = dataset.color || colors[datasetIndex % colors.length];
      
      // Create line
      g.append('path')
        .datum(dataset.data)
        .attr('fill', 'none')
        .attr('stroke', color)
        .attr('stroke-width', 3)
        .attr('d', line)
        .attr('opacity', 0.8);
      
      // Create dots for each data point
      g.selectAll(`.dot-${datasetIndex}`)
        .data(dataset.data)
        .enter()
        .append('circle')
        .attr('class', `dot-${datasetIndex}`)
        .attr('cx', (_, i) => xScale(data.labels[i]) || 0)
        .attr('cy', d => yScale(d))
        .attr('r', 4)
        .attr('fill', 'white')
        .attr('stroke', color)
        .attr('stroke-width', 2)
        .on('mouseover', function(event, d) {
          d3.select(this)
            .transition()
            .duration(200)
            .attr('r', 6);
          
          // Show tooltip
          const xPos = parseFloat(d3.select(this).attr('cx'));
          const yPos = parseFloat(d3.select(this).attr('cy'));
          
          g.append('text')
            .attr('class', 'tooltip')
            .attr('x', xPos)
            .attr('y', yPos - 15)
            .attr('text-anchor', 'middle')
            .attr('font-size', '12px')
            .attr('fill', '#4B5563')
            .text(d);
        })
        .on('mouseout', function() {
          d3.select(this)
            .transition()
            .duration(200)
            .attr('r', 4);
          
          // Remove tooltip
          g.selectAll('.tooltip').remove();
        });
    });
    
    // Add X axis
    g.append('g')
      .attr('transform', `translate(0,${innerHeight})`)
      .call(d3.axisBottom(xScale))
      .selectAll('text')
      .attr('fill', '#6B7280')
      .attr('font-size', '10px')
      .style('text-anchor', 'middle');
    
    // Add Y axis
    g.append('g')
      .call(d3.axisLeft(yScale).ticks(5))
      .selectAll('text')
      .attr('fill', '#6B7280')
      .attr('font-size', '10px');
    
    // Remove axis lines
    g.selectAll('.domain, .tick line')
      .attr('stroke', '#E5E7EB');
    
    // Add legend
    const legend = svg.append('g')
      .attr('transform', `translate(${width - margin.right + 20}, ${margin.top})`);
    
    data.datasets.forEach((dataset, i) => {
      const color = dataset.color || colors[i % colors.length];
      
      const legendRow = legend.append('g')
        .attr('transform', `translate(0, ${i * 20})`);
      
      legendRow.append('line')
        .attr('x1', 0)
        .attr('y1', 0)
        .attr('x2', 15)
        .attr('y2', 0)
        .attr('stroke', color)
        .attr('stroke-width', 3);
      
      legendRow.append('text')
        .attr('x', 20)
        .attr('y', 5)
        .attr('font-size', '12px')
        .attr('fill', '#4B5563')
        .text(dataset.name);
    });
    
  }, [data, width, height]);
  
  return (
    <div className="bg-white p-5 rounded-xl shadow-sm">
      {title && <h3 className="text-lg font-semibold text-gray-800 mb-4">{title}</h3>}
      <svg ref={svgRef} width={width} height={height} />
    </div>
  );
};

export default LineChart;