import React from 'react';
import { Menu, Bell, Search } from 'lucide-react';

interface HeaderProps {
  toggleSidebar: () => void;
}

const Header: React.FC<HeaderProps> = ({ toggleSidebar }) => {
  return (
    <header className="bg-white shadow-sm py-4 px-6 flex items-center justify-between">
      <div className="flex items-center">
        <button 
          onClick={toggleSidebar}
          className="text-gray-500 hover:text-blue-600 focus:outline-none mr-4 lg:hidden"
        >
          <Menu size={24} />
        </button>
        <h1 className="text-2xl font-semibold text-gray-800">
          MediCare <span className="text-blue-600">HMS</span>
        </h1>
      </div>
      
      <div className="hidden md:flex items-center relative mx-auto max-w-md w-full px-4">
        <Search size={18} className="absolute left-8 text-gray-400" />
        <input 
          type="text" 
          placeholder="Search patients, doctors, etc." 
          className="pl-10 pr-4 py-2 bg-gray-100 rounded-full w-full focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
        />
      </div>
      
      <div className="flex items-center">
        <button className="relative p-2 text-gray-500 hover:text-blue-600 focus:outline-none">
          <Bell size={20} />
          <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
        </button>
        <div className="ml-4 flex items-center">
          <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-semibold">
            DR
          </div>
          <span className="ml-2 text-sm font-medium text-gray-700 hidden md:inline-block">Dr. Roberts</span>
        </div>
      </div>
    </header>
  );
};

export default Header;