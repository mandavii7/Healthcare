import React, { useState } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import Header from './Header';
import Sidebar from './Sidebar';

const Layout: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  
  const currentSection = location.pathname.split('/')[1] || 'dashboard';
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  const handleNavigate = (section: string) => {
    navigate(`/${section}`);
    setSidebarOpen(false);
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header toggleSidebar={toggleSidebar} />
      
      <Sidebar 
        isOpen={sidebarOpen} 
        currentSection={currentSection} 
        onNavigate={handleNavigate} 
      />
      
      <div 
        className={`lg:ml-64 transition-all duration-300 ease-in-out pt-16 min-h-screen`}
      >
        <main className="p-6">
          <Outlet />
        </main>
      </div>
      
      {/* Overlay for mobile sidebar */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-20 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        ></div>
      )}
    </div>
  );
};

export default Layout;