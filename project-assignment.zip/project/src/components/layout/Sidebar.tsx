import React from 'react';
import { 
  Home, 
  Users, 
  Calendar, 
  BarChart2, 
  FileText, 
  Settings,
  LogOut
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  currentSection: string;
  onNavigate: (section: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, currentSection, onNavigate }) => {
  const navItems = [
    { name: 'Dashboard', icon: Home },
    { name: 'Patients', icon: Users },
    { name: 'Appointments', icon: Calendar },
    { name: 'Analytics', icon: BarChart2 },
    { name: 'Reports', icon: FileText },
    { name: 'Settings', icon: Settings },
  ];
  
  return (
    <aside 
      className={`bg-white border-r border-gray-200 w-64 fixed top-0 bottom-0 left-0 z-30 transition-transform duration-300 ease-in-out transform ${
        isOpen ? 'translate-x-0' : '-translate-x-full'
      } lg:translate-x-0`}
    >
      <div className="h-full flex flex-col">
        <div className="flex items-center justify-center h-16 border-b border-gray-200">
          <h2 className="text-xl font-bold text-blue-600">MediCare HMS</h2>
        </div>
        
        <nav className="flex-1 px-4 py-4 overflow-y-auto">
          <ul className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentSection === item.name.toLowerCase();
              
              return (
                <li key={item.name}>
                  <button
                    onClick={() => onNavigate(item.name.toLowerCase())}
                    className={`flex items-center w-full px-4 py-3 rounded-lg transition-colors ${
                      isActive 
                        ? 'bg-blue-50 text-blue-600' 
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <Icon size={20} className={isActive ? 'text-blue-600' : 'text-gray-500'} />
                    <span className="ml-3 font-medium">{item.name}</span>
                    {item.name === 'Patients' && (
                      <span className="ml-auto bg-blue-100 text-blue-800 text-xs font-medium px-2 py-0.5 rounded-full">
                        30
                      </span>
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
          
          <div className="pt-8 mt-auto">
            <div className="border-t border-gray-200 pt-4">
              <button
                className="flex items-center w-full px-4 py-3 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <LogOut size={20} className="text-gray-500" />
                <span className="ml-3 font-medium">Logout</span>
              </button>
            </div>
          </div>
        </nav>
      </div>
    </aside>
  );
};

export default Sidebar;