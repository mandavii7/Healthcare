import React, { useState } from 'react';
import { Download, FileText, Filter, Calendar, ChevronDown } from 'lucide-react';
import { usePatients } from '../context/PatientContext';

const Reports: React.FC = () => {
  const { patients } = usePatients();
  const [activeReport, setActiveReport] = useState('patient-summary');
  
  // Available reports
  const reports = [
    { id: 'patient-summary', name: 'Patient Summary Report', description: 'Overview of all patients with key metrics' },
    { id: 'admissions', name: 'Admissions Report', description: 'Analysis of patient admissions over time' },
    { id: 'discharge', name: 'Discharge Report', description: 'Summary of patient discharges and outcomes' },
    { id: 'vitals', name: 'Vital Signs Report', description: 'Trends and analysis of patient vital signs' },
    { id: 'follow-ups', name: 'Follow-up Appointments', description: 'Schedule of upcoming follow-up appointments' },
  ];
  
  // Simple statistics for the patient summary report
  const patientStats = {
    totalPatients: patients.length,
    activePatients: patients.filter(p => !p.dischargeDate).length,
    malePatients: patients.filter(p => p.gender === 'Male').length,
    femalePatients: patients.filter(p => p.gender === 'Female').length,
    averageAge: Math.round(patients.reduce((sum, patient) => {
      const birthDate = new Date(patient.dateOfBirth);
      const age = new Date().getFullYear() - birthDate.getFullYear();
      return sum + age;
    }, 0) / patients.length),
    highRiskPatients: patients.filter(p => 
      p.medicalHistory?.some(condition => 
        ['Heart Disease', 'Cancer', 'Stroke'].includes(condition)
      )
    ).length,
  };
  
  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Reports</h1>
          <p className="text-gray-500 mt-1">Generate and view healthcare reports</p>
        </div>
        
        <div className="flex items-center space-x-2 mt-4 md:mt-0">
          <div className="flex items-center p-2 text-gray-500 bg-white rounded-lg border border-gray-200">
            <Calendar size={16} className="mr-2" />
            <select className="bg-transparent focus:outline-none text-sm">
              <option>Last 30 days</option>
              <option>Last 90 days</option>
              <option>Last 6 months</option>
              <option>Last year</option>
              <option>Custom range</option>
            </select>
          </div>
          
          <button className="flex items-center p-2 text-gray-500 hover:text-blue-600 bg-white rounded-lg border border-gray-200">
            <Download size={16} />
            <span className="ml-2 text-sm">Export</span>
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Reports Sidebar */}
        <div className="bg-white rounded-xl shadow-sm p-4">
          <h2 className="font-medium text-gray-800 mb-4">Available Reports</h2>
          
          <div className="space-y-2">
            {reports.map(report => (
              <button
                key={report.id}
                onClick={() => setActiveReport(report.id)}
                className={`w-full text-left p-3 rounded-lg transition-colors ${
                  activeReport === report.id
                    ? 'bg-blue-50 text-blue-800'
                    : 'hover:bg-gray-50 text-gray-700'
                }`}
              >
                <div className="flex items-start">
                  <FileText size={16} className={activeReport === report.id ? 'text-blue-600' : 'text-gray-500'} />
                  <div className="ml-3">
                    <p className="font-medium">{report.name}</p>
                    <p className="text-xs text-gray-500 mt-1">{report.description}</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
        
        {/* Report Content */}
        <div className="md:col-span-3 bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="p-5 border-b border-gray-100">
            <h2 className="text-lg font-semibold text-gray-800">
              {reports.find(r => r.id === activeReport)?.name}
            </h2>
          </div>
          
          {activeReport === 'patient-summary' && (
            <div className="p-5">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-blue-50 border border-blue-100 rounded-lg p-4">
                  <h3 className="text-sm text-blue-800 font-medium">Total Patients</h3>
                  <p className="text-2xl font-bold mt-1">{patientStats.totalPatients}</p>
                </div>
                
                <div className="bg-green-50 border border-green-100 rounded-lg p-4">
                  <h3 className="text-sm text-green-800 font-medium">Active Patients</h3>
                  <p className="text-2xl font-bold mt-1">{patientStats.activePatients}</p>
                </div>
                
                <div className="bg-red-50 border border-red-100 rounded-lg p-4">
                  <h3 className="text-sm text-red-800 font-medium">High Risk Patients</h3>
                  <p className="text-2xl font-bold mt-1">{patientStats.highRiskPatients}</p>
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="font-medium text-gray-800 mb-3">Patient Demographics</h3>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">Gender Distribution</p>
                      <div className="flex items-center mt-2">
                        <div className="w-24 bg-gray-200 h-6 rounded-l-full overflow-hidden">
                          <div 
                            className="bg-blue-500 h-full" 
                            style={{ width: `${(patientStats.malePatients / patientStats.totalPatients) * 100}%` }}
                          ></div>
                        </div>
                        <div className="w-24 bg-gray-200 h-6 rounded-r-full overflow-hidden">
                          <div 
                            className="bg-pink-500 h-full" 
                            style={{ width: `${(patientStats.femalePatients / patientStats.totalPatients) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                      <div className="flex justify-between text-xs mt-1">
                        <span>Male: {patientStats.malePatients} ({Math.round((patientStats.malePatients / patientStats.totalPatients) * 100)}%)</span>
                        <span>Female: {patientStats.femalePatients} ({Math.round((patientStats.femalePatients / patientStats.totalPatients) * 100)}%)</span>
                      </div>
                    </div>
                    
                    <div>
                      <p className="text-sm text-gray-500">Average Age</p>
                      <p className="text-2xl font-bold mt-2">{patientStats.averageAge} years</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <h3 className="font-medium text-gray-800 mb-3">Patient List</h3>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Name
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Gender
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Age
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Admission Date
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {patients.slice(0, 10).map((patient) => {
                      const birthDate = new Date(patient.dateOfBirth);
                      const age = new Date().getFullYear() - birthDate.getFullYear();
                      
                      return (
                        <tr key={patient.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">
                              {patient.firstName} {patient.lastName}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-500">{patient.gender}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-500">{age}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              patient.dischargeDate
                                ? 'bg-green-100 text-green-800'
                                : 'bg-blue-100 text-blue-800'
                            }`}>
                              {patient.dischargeDate ? 'Discharged' : 'Active'}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {patient.admissionDate || 'N/A'}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              
              <div className="text-right mt-4">
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm">
                  View Complete Report
                </button>
              </div>
            </div>
          )}
          
          {activeReport !== 'patient-summary' && (
            <div className="p-12 text-center">
              <div className="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                <FileText size={24} className="text-gray-500" />
              </div>
              <h3 className="text-lg font-medium text-gray-800 mb-2">Report in Development</h3>
              <p className="text-gray-500 max-w-md mx-auto">
                This report is currently being developed. Please check back later or contact the administration for more information.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Reports;