import React from 'react';
import { RefreshCw, Download, Filter } from 'lucide-react';
import BarChart from '../components/charts/BarChart';
import PieChart from '../components/charts/PieChart';
import LineChart from '../components/charts/LineChart';
import { useAnalytics } from '../context/AnalyticsContext';

const Analytics: React.FC = () => {
  const { analytics, refreshAnalytics } = useAnalytics();
  
  // Prepare admission data for line chart
  const admissionData = {
    labels: analytics.admissionsByMonth.map(item => item.month),
    datasets: [
      {
        name: 'Admissions',
        data: analytics.admissionsByMonth.map(item => item.count),
        color: '#3B82F6'
      }
    ]
  };
  
  // Calculate total risk patients
  const totalRiskPatients = 
    analytics.riskAssessment.highRisk + 
    analytics.riskAssessment.mediumRisk + 
    analytics.riskAssessment.lowRisk;
  
  // Prepare risk data for pie chart
  const riskData = [
    { label: 'High Risk', value: analytics.riskAssessment.highRisk },
    { label: 'Medium Risk', value: analytics.riskAssessment.mediumRisk },
    { label: 'Low Risk', value: analytics.riskAssessment.lowRisk },
  ];
  
  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Analytics Dashboard</h1>
          <p className="text-gray-500 mt-1">Analyze patient data and hospital performance</p>
        </div>
        
        <div className="flex items-center space-x-2 mt-4 md:mt-0">
          <button 
            onClick={refreshAnalytics}
            className="flex items-center p-2 text-gray-500 hover:text-blue-600 bg-white rounded-lg border border-gray-200"
          >
            <RefreshCw size={16} />
            <span className="ml-2 text-sm">Refresh</span>
          </button>
          
          <button className="flex items-center p-2 text-gray-500 hover:text-blue-600 bg-white rounded-lg border border-gray-200">
            <Download size={16} />
            <span className="ml-2 text-sm">Export</span>
          </button>
          
          <div className="flex items-center p-2 text-gray-500 bg-white rounded-lg border border-gray-200">
            <Filter size={16} />
            <select className="ml-2 text-sm bg-transparent focus:outline-none">
              <option>Last 30 days</option>
              <option>Last 90 days</option>
              <option>Last 6 months</option>
              <option>Last year</option>
            </select>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Admissions by Month */}
        <div>
          <LineChart 
            data={admissionData}
            title="Monthly Admissions"
            height={300}
            width={600}
          />
        </div>
        
        {/* Patient Demographics */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <PieChart 
            data={analytics.patientsByGender}
            title="Gender Distribution"
            height={300}
            width={300}
          />
          
          <PieChart 
            data={riskData}
            title="Risk Assessment"
            height={300}
            width={300}
            colors={['#EF4444', '#F97316', '#10B981']}
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Patients by Age */}
        <BarChart 
          data={analytics.patientsByAge}
          title="Patients by Age Group"
          height={300}
          width={600}
        />
        
        {/* Vital Signs Trends */}
        <LineChart 
          data={analytics.vitalTrends}
          title="Average Vital Signs Trends"
          height={300}
          width={600}
        />
      </div>
      
      {/* Key Insights */}
      <div className="mt-8 bg-white rounded-xl shadow-sm p-6">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">Key Insights & Recommendations</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-4 bg-blue-50 border border-blue-100 rounded-lg">
            <h3 className="font-medium text-blue-800 mb-2">Patient Demographics</h3>
            <ul className="space-y-2 text-sm">
              <li>The largest age group is {analytics.patientsByAge.reduce((a, b) => a.value > b.value ? a : b).label} with {analytics.patientsByAge.reduce((a, b) => a.value > b.value ? a : b).value} patients</li>
              <li>Gender distribution shows {Math.round(analytics.patientsByGender[0].value / (analytics.patientsByGender[0].value + analytics.patientsByGender[1].value) * 100)}% {analytics.patientsByGender[0].label} patients</li>
              <li><strong>Recommendation:</strong> Consider targeted healthcare programs for the dominant demographic groups</li>
            </ul>
          </div>
          
          <div className="p-4 bg-orange-50 border border-orange-100 rounded-lg">
            <h3 className="font-medium text-orange-800 mb-2">Admission Patterns</h3>
            <ul className="space-y-2 text-sm">
              <li>Highest admission month: {analytics.admissionsByMonth.reduce((a, b) => a.count > b.count ? a : b).month} with {analytics.admissionsByMonth.reduce((a, b) => a.count > b.count ? a : b).count} admissions</li>
              <li>Average stay duration: {analytics.averageStayDuration} days</li>
              <li><strong>Recommendation:</strong> Increase staffing during peak months to maintain quality of care</li>
            </ul>
          </div>
          
          <div className="p-4 bg-green-50 border border-green-100 rounded-lg">
            <h3 className="font-medium text-green-800 mb-2">Vital Signs Trends</h3>
            <ul className="space-y-2 text-sm">
              <li>Average heart rate has {analytics.vitalTrends.datasets[0].data[0] < analytics.vitalTrends.datasets[0].data[analytics.vitalTrends.datasets[0].data.length - 1] ? 'increased' : 'decreased'} over the monitored period</li>
              <li>Blood pressure readings show {analytics.vitalTrends.datasets[1].data[0] < analytics.vitalTrends.datasets[1].data[analytics.vitalTrends.datasets[1].data.length - 1] ? 'an upward' : 'a downward'} trend</li>
              <li><strong>Recommendation:</strong> Monitor patients with consistently high readings more frequently</li>
            </ul>
          </div>
          
          <div className="p-4 bg-red-50 border border-red-100 rounded-lg">
            <h3 className="font-medium text-red-800 mb-2">Risk Assessment</h3>
            <ul className="space-y-2 text-sm">
              <li>{analytics.riskAssessment.highRisk} patients ({Math.round(analytics.riskAssessment.highRisk / totalRiskPatients * 100)}%) are classified as high risk</li>
              <li>Most common high-risk conditions: Heart Disease, Stroke, and Cancer</li>
              <li><strong>Recommendation:</strong> Implement specialized care protocols for high-risk patients to prevent complications</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;