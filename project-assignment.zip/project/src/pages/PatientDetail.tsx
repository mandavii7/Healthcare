import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Edit, Calendar, FileText, Activity, User, AlertTriangle } from 'lucide-react';
import PatientForm from '../components/patients/PatientForm';
import LineChart from '../components/charts/LineChart';
import { usePatients } from '../context/PatientContext';

const PatientDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getPatientById, updatePatient } = usePatients();
  const [showEditForm, setShowEditForm] = useState(false);
  
  const patient = getPatientById(id || '');
  
  if (!patient) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Patient Not Found</h2>
        <p className="text-gray-500 mb-6">The patient you're looking for doesn't exist or has been removed.</p>
        <button 
          onClick={() => navigate('/patients')}
          className="inline-flex items-center text-blue-600 hover:text-blue-800"
        >
          <ArrowLeft size={16} className="mr-2" />
          Back to Patients
        </button>
      </div>
    );
  }
  
  const age = new Date().getFullYear() - new Date(patient.dateOfBirth).getFullYear();
  
  // Prepare vitals data for chart
  const vitalDates = patient.vitalSigns?.map(v => v.date) || [];
  const heartRateData = patient.vitalSigns?.map(v => v.heartRate) || [];
  const systolicData = patient.vitalSigns?.map(v => v.bloodPressureSystolic) || [];
  const diastolicData = patient.vitalSigns?.map(v => v.bloodPressureDiastolic) || [];
  
  const vitalsChartData = {
    labels: vitalDates,
    datasets: [
      {
        name: 'Heart Rate',
        data: heartRateData,
        color: '#3B82F6'
      },
      {
        name: 'Systolic BP',
        data: systolicData,
        color: '#F97316'
      },
      {
        name: 'Diastolic BP',
        data: diastolicData,
        color: '#10B981'
      }
    ]
  };
  
  const handleEditPatient = async (updatedData: Partial<Patient>) => {
    if (id) {
      await updatePatient(id, updatedData);
      setShowEditForm(false);
    }
  };
  
  const isHighRisk = patient.medicalHistory?.some(h => 
    ['Heart Disease', 'Cancer', 'Stroke'].includes(h)
  );
  
  return (
    <div>
      <div className="mb-6">
        <button 
          onClick={() => navigate('/patients')}
          className="inline-flex items-center text-gray-600 hover:text-blue-600"
        >
          <ArrowLeft size={16} className="mr-2" />
          Back to Patients
        </button>
        
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mt-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">
              {patient.firstName} {patient.lastName}
              {isHighRisk && (
                <span className="ml-2 inline-flex items-center bg-red-100 text-red-800 text-xs px-2 py-1 rounded-full">
                  <AlertTriangle size={12} className="mr-1" />
                  High Risk
                </span>
              )}
            </h1>
            <p className="text-gray-500 mt-1">
              {patient.gender}, {age} years old • ID: {patient.id.slice(0, 8)}
            </p>
          </div>
          
          <button 
            onClick={() => setShowEditForm(true)}
            className="mt-4 md:mt-0 flex items-center text-sm bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Edit size={16} className="mr-2" />
            Edit Patient
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Patient Info */}
        <div className="bg-white rounded-xl shadow-sm p-5">
          <h2 className="flex items-center text-lg font-semibold text-gray-800 mb-4">
            <User size={18} className="mr-2 text-blue-600" />
            Patient Information
          </h2>
          
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-medium text-gray-500">Contact Details</h3>
              <p className="mt-1">{patient.contactNumber}</p>
              <p className="mt-1">{patient.email}</p>
              <p className="mt-1">{patient.address}</p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-500">Insurance</h3>
              <p className="mt-1">{patient.insuranceProvider || 'Not provided'}</p>
              <p className="mt-1">Policy #: {patient.insuranceNumber || 'Not provided'}</p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-500">Emergency Contact</h3>
              <p className="mt-1">{patient.emergencyContact || 'Not provided'}</p>
              <p className="mt-1">{patient.emergencyPhone || 'Not provided'}</p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-500">Hospital Status</h3>
              <p className="mt-1">Assigned Doctor: {patient.assignedDoctor || 'Not assigned'}</p>
              <p className="mt-1">Admission Date: {patient.admissionDate || 'Not admitted'}</p>
              {patient.dischargeDate && (
                <p className="mt-1">Discharge Date: {patient.dischargeDate}</p>
              )}
            </div>
          </div>
        </div>
        
        {/* Medical Information */}
        <div className="bg-white rounded-xl shadow-sm p-5">
          <h2 className="flex items-center text-lg font-semibold text-gray-800 mb-4">
            <FileText size={18} className="mr-2 text-blue-600" />
            Medical Information
          </h2>
          
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-medium text-gray-500">Blood Type</h3>
              <p className="mt-1">{patient.bloodType || 'Not recorded'}</p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-500">Allergies</h3>
              {patient.allergies && patient.allergies.length > 0 ? (
                <ul className="mt-1 list-disc list-inside">
                  {patient.allergies.map((allergy, index) => (
                    <li key={index}>{allergy}</li>
                  ))}
                </ul>
              ) : (
                <p className="mt-1">No known allergies</p>
              )}
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-500">Medical History</h3>
              {patient.medicalHistory && patient.medicalHistory.length > 0 ? (
                <ul className="mt-1 list-disc list-inside">
                  {patient.medicalHistory.map((condition, index) => (
                    <li key={index} className={condition === 'Heart Disease' ? 'text-red-600 font-medium' : ''}>
                      {condition}
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="mt-1">No medical history recorded</p>
              )}
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-500">Current Medications</h3>
              {patient.currentMedications && patient.currentMedications.length > 0 ? (
                <ul className="mt-1 list-disc list-inside">
                  {patient.currentMedications.map((medication, index) => (
                    <li key={index}>{medication}</li>
                  ))}
                </ul>
              ) : (
                <p className="mt-1">No current medications</p>
              )}
            </div>
          </div>
        </div>
        
        {/* Upcoming Appointments */}
        <div className="bg-white rounded-xl shadow-sm p-5">
          <h2 className="flex items-center text-lg font-semibold text-gray-800 mb-4">
            <Calendar size={18} className="mr-2 text-blue-600" />
            Appointments
          </h2>
          
          {patient.followupAppointments && patient.followupAppointments.length > 0 ? (
            <div className="space-y-4">
              {patient.followupAppointments.map((appointment) => (
                <div key={appointment.id} className="p-3 rounded-lg border border-gray-200">
                  <div className="flex justify-between">
                    <div>
                      <p className="font-medium">{appointment.date} at {appointment.time}</p>
                      <p className="text-sm text-gray-500">{appointment.purpose}</p>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      appointment.completed 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-blue-100 text-blue-800'
                    }`}>
                      {appointment.completed ? 'Completed' : 'Upcoming'}
                    </span>
                  </div>
                  <div className="flex items-center mt-2 text-sm text-gray-500">
                    <User size={14} className="mr-1" />
                    <span>{appointment.doctorName}</span>
                  </div>
                  {appointment.notes && (
                    <p className="mt-2 text-sm italic text-gray-500">
                      Note: {appointment.notes}
                    </p>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500">No appointments scheduled</p>
          )}
          
          <button className="mt-4 w-full text-center px-4 py-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 transition-colors text-sm">
            Schedule New Appointment
          </button>
        </div>
        
        {/* Vital Signs Chart */}
        <div className="md:col-span-3">
          <div className="bg-white rounded-xl shadow-sm p-5">
            <h2 className="flex items-center text-lg font-semibold text-gray-800 mb-4">
              <Activity size={18} className="mr-2 text-blue-600" />
              Vital Signs History
            </h2>
            
            {patient.vitalSigns && patient.vitalSigns.length > 0 ? (
              <LineChart 
                data={vitalsChartData}
                height={350}
                width={1000}
              />
            ) : (
              <p className="text-gray-500 text-center py-12">No vital signs recorded for this patient.</p>
            )}
          </div>
        </div>
      </div>
      
      {showEditForm && (
        <PatientForm
          initialData={patient}
          isEditing={true}
          onSubmit={handleEditPatient}
          onCancel={() => setShowEditForm(false)}
        />
      )}
    </div>
  );
};

export default PatientDetail;