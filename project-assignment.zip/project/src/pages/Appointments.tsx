import React, { useState } from 'react';
import { Calendar, ChevronLeft, ChevronRight, Search, Filter, Plus } from 'lucide-react';
import { usePatients } from '../context/PatientContext';
import { format, startOfWeek, addDays, isSameDay, parse } from 'date-fns';
import { FollowupAppointment } from '../types';

interface AppointmentWithPatient extends FollowupAppointment {
  patientName: string;
  patientId: string;
}

const Appointments: React.FC = () => {
  const { patients } = usePatients();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'upcoming' | 'completed'>('all');
  
  // Extract all appointments
  const allAppointments: AppointmentWithPatient[] = patients.flatMap(patient => 
    (patient.followupAppointments || []).map(appointment => ({
      ...appointment,
      patientName: `${patient.firstName} ${patient.lastName}`,
      patientId: patient.id
    }))
  );
  
  // Apply filters
  const filteredAppointments = allAppointments.filter(appointment => {
    const matchesSearch = appointment.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          appointment.purpose.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          appointment.doctorName.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || 
                         (statusFilter === 'completed' && appointment.completed) ||
                         (statusFilter === 'upcoming' && !appointment.completed);
    
    return matchesSearch && matchesStatus;
  });
  
  // Get the current week dates
  const getWeekDates = () => {
    const startOfCurrentWeek = startOfWeek(currentDate, { weekStartsOn: 1 });
    return Array.from({ length: 7 }, (_, i) => addDays(startOfCurrentWeek, i));
  };
  
  const weekDates = getWeekDates();
  
  // Group appointments by day
  const appointmentsByDay = weekDates.map(date => {
    const formattedDate = format(date, 'yyyy-MM-dd');
    return {
      date,
      appointments: filteredAppointments.filter(a => a.date === formattedDate)
    };
  });
  
  const handlePreviousWeek = () => {
    setCurrentDate(prevDate => addDays(prevDate, -7));
  };
  
  const handleNextWeek = () => {
    setCurrentDate(prevDate => addDays(prevDate, 7));
  };
  
  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Appointments</h1>
        
        <button className="mt-4 md:mt-0 flex items-center text-sm bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
          <Plus size={16} className="mr-2" />
          New Appointment
        </button>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-8">
        <div className="p-5 border-b border-gray-100">
          <div className="flex flex-col md:flex-row md:items-center justify-between">
            <div className="relative w-full md:w-80">
              <Search size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input 
                type="text" 
                placeholder="Search appointments..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 bg-gray-100 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
              />
            </div>
            
            <div className="flex items-center mt-4 md:mt-0 space-x-2">
              <span className="text-gray-500 flex items-center">
                <Filter size={16} className="mr-2" />
                Status:
              </span>
              {['all', 'upcoming', 'completed'].map((status) => (
                <button
                  key={status}
                  onClick={() => setStatusFilter(status as 'all' | 'upcoming' | 'completed')}
                  className={`px-3 py-1 text-xs rounded-full ${
                    statusFilter === status
                      ? 'bg-blue-100 text-blue-800'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {status.charAt(0).toUpperCase() + status.slice(1)}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="p-4 border-b border-gray-100 flex items-center justify-between">
          <button
            onClick={handlePreviousWeek}
            className="p-2 rounded-lg text-gray-500 hover:bg-gray-100"
          >
            <ChevronLeft size={20} />
          </button>
          
          <div className="flex items-center">
            <Calendar size={18} className="text-blue-600 mr-2" />
            <span className="font-medium">
              {format(weekDates[0], 'MMM d')} - {format(weekDates[6], 'MMM d, yyyy')}
            </span>
          </div>
          
          <button
            onClick={handleNextWeek}
            className="p-2 rounded-lg text-gray-500 hover:bg-gray-100"
          >
            <ChevronRight size={20} />
          </button>
        </div>
        
        <div className="grid grid-cols-7 border-b border-gray-100">
          {weekDates.map((date, index) => (
            <div 
              key={index} 
              className={`p-3 text-center border-r border-gray-100 last:border-r-0 ${
                isSameDay(date, new Date()) ? 'bg-blue-50' : ''
              }`}
            >
              <p className="text-gray-500 text-xs">{format(date, 'EEE')}</p>
              <p className={`text-lg ${isSameDay(date, new Date()) ? 'text-blue-600 font-medium' : ''}`}>
                {format(date, 'd')}
              </p>
            </div>
          ))}
        </div>
        
        <div className="grid grid-cols-7 min-h-[500px]">
          {appointmentsByDay.map((day, dayIndex) => (
            <div 
              key={dayIndex}
              className={`border-r border-gray-100 last:border-r-0 p-2 ${
                isSameDay(day.date, new Date()) ? 'bg-blue-50' : ''
              }`}
            >
              {day.appointments.length > 0 ? (
                day.appointments.map((appointment, appIndex) => (
                  <div 
                    key={appointment.id}
                    className={`p-2 mb-2 rounded-lg text-sm ${
                      appointment.completed
                        ? 'bg-green-50 border border-green-100'
                        : 'bg-blue-50 border border-blue-100'
                    }`}
                  >
                    <p className="font-medium">{appointment.time}</p>
                    <p>{appointment.patientName}</p>
                    <p className="text-xs text-gray-500">{appointment.purpose}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      {appointment.doctorName}
                    </p>
                  </div>
                ))
              ) : (
                <div className="h-full flex items-center justify-center">
                  <p className="text-gray-400 text-xs">No appointments</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Appointments;