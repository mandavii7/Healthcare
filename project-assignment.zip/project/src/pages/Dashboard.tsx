import React from 'react';
import { Users, Activity, Calendar, TrendingUp } from 'lucide-react';
import DashboardHeader from '../components/dashboard/DashboardHeader';
import StatCard from '../components/dashboard/StatCard';
import AppointmentCard from '../components/dashboard/AppointmentCard';
import PatientListItem from '../components/dashboard/PatientListItem';
import { usePatients } from '../context/PatientContext';
import { useAnalytics } from '../context/AnalyticsContext';
import LineChart from '../components/charts/LineChart';

const Dashboard: React.FC = () => {
  const { patients } = usePatients();
  const { analytics } = useAnalytics();
  
  // Extract active patients (those without a discharge date)
  const activePatients = patients.filter(p => !p.dischargeDate);
  
  // Get recent appointments (would come from appointments data in a real app)
  const todayAppointments = patients
    .flatMap(p => (p.followupAppointments || []).map(a => ({
      ...a,
      patientName: `${p.firstName} ${p.lastName}`
    })))
    .filter(a => !a.completed)
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 3);
  
  // Get recent admitted patients
  const recentPatients = [...patients]
    .sort((a, b) => {
      const dateA = a.admissionDate ? new Date(a.admissionDate) : new Date(0);
      const dateB = b.admissionDate ? new Date(b.admissionDate) : new Date(0);
      return dateB.getTime() - dateA.getTime();
    })
    .slice(0, 5);
  
  return (
    <div>
      <DashboardHeader />
      
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard 
          title="Total Patients" 
          value={patients.length}
          icon={<Users size={20} />}
          change={{ value: 12, type: 'increase' }}
          bgColor="bg-blue-500"
        />
        
        <StatCard 
          title="Active Patients" 
          value={activePatients.length}
          icon={<Activity size={20} />}
          change={{ value: 8, type: 'increase' }}
          bgColor="bg-green-500"
        />
        
        <StatCard 
          title="Today's Appointments" 
          value={todayAppointments.length}
          icon={<Calendar size={20} />}
          bgColor="bg-orange-500"
        />
        
        <StatCard 
          title="Avg. Stay Duration" 
          value={`${analytics.averageStayDuration} days`}
          icon={<TrendingUp size={20} />}
          change={{ value: 2.5, type: 'decrease' }}
          bgColor="bg-purple-500"
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Vital Signs Trends */}
        <div className="lg:col-span-2">
          <LineChart 
            data={analytics.vitalTrends}
            title="Vital Signs Trends"
            height={300}
            width={800}
          />
        </div>
        
        {/* Today's Appointments */}
        <div className="bg-white rounded-xl shadow-sm p-5">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Today's Appointments</h3>
          <div className="space-y-4">
            {todayAppointments.length > 0 ? (
              todayAppointments.map((appointment) => (
                <AppointmentCard
                  key={appointment.id}
                  time={appointment.time}
                  patientName={appointment.patientName}
                  purposeShort={appointment.purpose}
                  location="Room 203, East Wing"
                  status="upcoming"
                />
              ))
            ) : (
              <p className="text-gray-500 text-center py-6">No appointments scheduled for today.</p>
            )}
          </div>
        </div>
      </div>
      
      {/* Recent Patients */}
      <div className="mt-8 bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="p-5 border-b border-gray-100">
          <h3 className="text-lg font-semibold text-gray-800">Recent Patients</h3>
        </div>
        <div>
          {recentPatients.map((patient) => (
            <PatientListItem
              key={patient.id}
              name={`${patient.firstName} ${patient.lastName}`}
              gender={patient.gender}
              age={new Date().getFullYear() - new Date(patient.dateOfBirth).getFullYear()}
              condition={patient.medicalHistory?.join(', ')}
              admissionDate={patient.admissionDate || ''}
              isHighRisk={patient.medicalHistory?.includes('Heart Disease')}
              bloodPressure={patient.vitalSigns && patient.vitalSigns.length > 0 
                ? `${patient.vitalSigns[0].bloodPressureSystolic}/${patient.vitalSigns[0].bloodPressureDiastolic}` 
                : undefined}
              heartRate={patient.vitalSigns && patient.vitalSigns.length > 0 
                ? patient.vitalSigns[0].heartRate 
                : undefined}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;